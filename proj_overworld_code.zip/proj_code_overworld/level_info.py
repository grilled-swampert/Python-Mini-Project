levels = {
	0: {'node_pos': (200, 360), 'content': 'Instructions', 'unlock': 1},
	1: {'node_pos': (640, 360), 'content': 'Level 1', 'unlock': 2},
	2: {'node_pos': (1080, 360), 'content': 'Level 2', 'unlock': 2}
}
