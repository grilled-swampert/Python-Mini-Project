screen_width, screen_height = 1280, 720
